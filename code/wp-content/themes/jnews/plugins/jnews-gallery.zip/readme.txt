Change Log :

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0
- [NEW FEATURE] Double click expand for JNews Gallery

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.2 ==
- [BUG] Fix fullscreen mode issue

== 3.0.1 ==
- [IMPROVEMENT] Remove all white space on Google ad ID

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.0 ==
- First Release
