Change Log :

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0
- [IMPROVEMENT] Import post view, subtitle & primary category

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.2 ==
- [BUG] Fix post format issue

== 1.0.1 ==
- [IMPROVEMENT] More styling on backend

== 1.0.0 ==
- First Release
