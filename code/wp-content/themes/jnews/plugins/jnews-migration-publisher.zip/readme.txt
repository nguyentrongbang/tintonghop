Change Log :

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.2 ==
- [BUG] Fix minor bug

== 1.0.1 ==
- [IMPROVEMENT] Import post view counter

== 1.0.0 ==
- First Release
