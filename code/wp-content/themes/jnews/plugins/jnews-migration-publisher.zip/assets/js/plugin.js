(function($){
	
	"use strict";

	function do_migration()
	{	
		$('.jnews-migration-btn > .button').bind('click', function( e )
		{
			if ( $(this).hasClass('nodirect') ) 
			{
				e.preventDefault();
			}

			var $this = $('.jeg-migration-wrapper'),
				count = $this.find('.jnews-migration-btn').attr('data-post-count'),
				nonce = $this.find('.jnews-migration-btn .nonce').val(),
				width = 100 / count;

			if ( count > 0 )
			{
				$this.addClass('active');

	            $this.find('.jnews-migration-btn .button').html( 
	            	'<i class="fa fa-refresh fa-spin fa-3x fa-fw"></i>' + 
	            	$this.find('.jnews-migration-btn .button').data('progress') 
	            );
	            $this.find('.progress-line span').html( 0 + '/' + count );

				ajax_migrate( $this, nonce, count, width, 0 );

				$this.find('.jnews-migration-btn').attr('data-post-count', 0);
			}
		});
	}

	function ajax_migrate( container, nonce, count, width, index )
	{
		$.ajax({
	        url   	 : ajaxurl,
	        type  	 : 'post',
	        dataType : 'json',
	        data 	 : 
	        {
	            action : 'jnews_content_migration_publisher',
	            nonce  : nonce
	        },
	        success: function ( data )
	        {
				index++;
	                
	            if ( index <= count )
	            {
	                container.find('.progress-line span').html( index + '/' + count );

	                container.find('.progress-line').width( (width * index) + '%'  );
	                
	                $('.migration-log-list').append('<li class="migration-notice ' + data.status + '">' + index + ') ' + data.message + '</li>');

	                ajax_migrate( container, nonce, count, width, index );

	            } else {
	                container.removeClass('active');

	                container.find('.migration-status').html( container.data('success') );

	                container.find('.jnews-migration-btn .button').html( 
	                	container.find('.jnews-migration-btn .button').data('success') 
	                ).removeClass('nodirect');
	            }
	        }
	    });
	}

	function dispatch()
	{
		do_migration();
	}

	$(document).ready( dispatch );

})(jQuery);